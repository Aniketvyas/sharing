from django.contrib import admin

from . models import *

admin.site.register(courses)
admin.site.register(blogs)
admin.site.register(Contact)
admin.site.register(courseContent)