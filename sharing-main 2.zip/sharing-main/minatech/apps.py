from django.apps import AppConfig


class MinatechConfig(AppConfig):
    name = 'minatech'
